from io import BytesIO
import boto3
import json
import base64
import logging
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from skpy import Skype, SkypeChats
from skpy import SkypeMsg
import os
HOOK_URL = os.environ['TEAMS_WEB_HOOK']
SKYPE_USERNAME = os.environ['SKYPE_USERNAME']
SKYPE_PASSWORD = os.environ['SKYPE_PASSWORD']
SKYPE_GROUP = os.environ['SKYPE_GROUP']
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    logger.info("Event: " + str(event))
    message = json.loads(event['Records'][0]['Sns']['Message']) #Processes messages from Amazon SNS, and logs their contents.
    alarm_name = message['AlarmName'] #Stores the value of key AlarmName
    old_state = message['OldStateValue'] #Stores the value of key OldStateValue
    new_state = message['NewStateValue'] #Stores the value of key NewStateValue
    reason = message['NewStateReason']
    namespace = message['Trigger']['Namespace'] #Stores the value of key AlarmName
    statistics = message['Trigger']['Statistic'] #Stores the value of key NewStateValue
    metricname = message['Trigger']['MetricName'] 
    dimensions = message['Trigger']['Dimensions']
    num = len(dimensions) #Stores the number od dimensions
    logger.info("Message: " + str(message))

    
    # SKYPE ALERT CODE
    
    skypemessage = ''' N Virginia Region \n Name of the Alarm : {} \n {} '''.format(alarm_name,reason)
    sk = Skype(SKYPE_USERNAME, SKYPE_PASSWORD) # connect to Skype
    ch = sk.chats[SKYPE_GROUP]
    ch.sendMsg(SkypeMsg.bold(skypemessage), rich=True)

    # TEAMS ALERT CODE

    base_data = {
        "color": "64a837",
        "title": "**%s** is resolved" % alarm_name,
        "text": "**%s** has changed from %s to %s - %s" % (alarm_name, old_state, new_state, reason)
    }
    if new_state.lower() == 'alarm':
        base_data = {
            "color": "d63333",
            "title": "Alert - There is an issue %s" % alarm_name,
            "text": "**%s** has changed from %s to %s - %s" % (alarm_name, old_state, new_state, reason)
        }

    message = {
      "@context": "https://schema.org/extensions",
      "@type": "MessageCard",
      "themeColor": base_data["color"],
      "title": base_data["title"],
      "text": base_data["text"]
    }

    req = Request(HOOK_URL, json.dumps(message).encode('utf-8'))
    try:
        response = urlopen(req)
        response.read()
        logger.info("Message posted")
    except HTTPError as e:
        logger.error("Request failed: %d %s", e.code, e.reason)
    except URLError as e:
        logger.error("Server connection failed: %s", e.reason)

    #To send graph
    propertieslist = []
    propertieslist.append(namespace)
    propertieslist.append(metricname)
    if num > 0:
        for i in reversed((range(num))):
            propertieslist.extend((dimensions[i]['name'],dimensions[i]['value']))
    if statistics == 'AVERAGE':    
        stat = {"stat":"Average"}
    elif statistics == 'SUM':
        stat = { "stat": "Sum" }            
    propertieslist.append(stat)



    cloudwatch = boto3.client('cloudwatch')
    
    met = {
                "view": "singleValue",
                "metrics": [
                    propertieslist
                ],
                "period": 300,
                "width": 1024,
                "height": 137,
                "start": "-PT3H",
                "end": "P0D"
            }
    response = cloudwatch.get_metric_widget_image(
        MetricWidget = json.dumps(met
            
                ))
  
    charts = base64.b64encode(response['MetricWidgetImage']).decode(encoding='utf-8')
    imgdata = base64.b64decode(charts)
    filename = '/tmp/graph.jpg' 
    with open(filename, 'wb') as f:
        f.write(imgdata)
    ch.sendFile(open('/tmp/graph.jpg', "rb"), "graph", image=True)    

